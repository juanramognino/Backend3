import { Router } from 'express';
import { usersService, petsService } from '../services/index.js';
import { createHash } from '../utils/index.js';

const router = Router();

// Datos simples para generar mocks
const roles = ['user', 'admin'];
const species = ['perro', 'gato', 'conejo', 'tortuga'];

/**
 * Función auxiliar para generar una mascota mock.
 */
const buildMockPet = (index) => {
  return {
    name: `Mascota${index + 1}`,
    specie: species[index % species.length],
    adopted: false
  };
};

/**
 * Función auxiliar para generar un usuario mock.
 * La contraseña siempre es "coder123" encriptada
 * y el array de mascotas arranca vacío.
 */
const buildMockUser = async (index) => {
  const hashedPassword = await createHash('coder123');

  return {
    first_name: `Usuario${index + 1}`,
    last_name: 'Mock',
    email: `usuario${index + 1}@test.com`,
    password: hashedPassword,
    role: roles[index % roles.length],
    pets: []
  };
};

/**
 * GET /api/mocks/mockingpets
 * Devuelve una lista de mascotas mockeadas sin guardar en la base.
 * Se puede pasar "cantidad" por query, por defecto son 50.
 */
router.get('/mockingpets', async (req, res) => {
  const cantidad = parseInt(req.query.cantidad) || 50;

  const pets = [];
  for (let i = 0; i < cantidad; i++) {
    pets.push({
      _id: `mock-pet-${i + 1}`,
      ...buildMockPet(i)
    });
  }

  res.send({ status: 'success', payload: pets });
});

/**
 * GET /api/mocks/mockingusers
 * Genera 50 usuarios mock con formato similar al de Mongo,
 * sin insertarlos en la base de datos.
 */
router.get('/mockingusers', async (req, res) => {
  const cantidad = 50;
  const users = [];

  for (let i = 0; i < cantidad; i++) {
    const user = await buildMockUser(i);
    users.push({
      _id: `mock-user-${i + 1}`,
      ...user
    });
  }

  res.send({ status: 'success', payload: users });
});

/**
 * POST /api/mocks/generateData
 * Recibe "users" y "pets" (body o query) y genera esa cantidad
 * de documentos en la base de datos utilizando los servicios.
 *
 * Ejemplo body:
 * {
 *   "users": 10,
 *   "pets": 5
 * }
 */
router.post('/generateData', async (req, res) => {
  try {
    const usersParam = req.body.users ?? req.query.users;
    const petsParam = req.body.pets ?? req.query.pets;

    const usersQty = parseInt(usersParam) || 0;
    const petsQty = parseInt(petsParam) || 0;

    if (usersQty <= 0 && petsQty <= 0) {
      return res.status(400).send({
        status: 'error',
        error: 'Debes indicar al menos users o pets mayor a 0'
      });
    }

    const createdUsers = [];
    const createdPets = [];

    // Generamos usuarios
    for (let i = 0; i < usersQty; i++) {
      const userData = await buildMockUser(i);
      const savedUser = await usersService.create(userData);
      createdUsers.push(savedUser);
    }

    // Generamos mascotas
    for (let i = 0; i < petsQty; i++) {
      const petData = buildMockPet(i);
      const savedPet = await petsService.create(petData);
      createdPets.push(savedPet);
    }

    res.send({
      status: 'success',
      insertedUsers: createdUsers.length,
      insertedPets: createdPets.length
    });
  } catch (error) {
    console.error('Error en /api/mocks/generateData', error);
    res.status(500).send({
      status: 'error',
      error: 'Error interno al generar datos'
    });
  }
});

export default router;
