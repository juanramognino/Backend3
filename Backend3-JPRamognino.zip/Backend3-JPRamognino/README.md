# Backend 3 - Dockerizado (JPRamognino)

Este repo cumple con la consigna de **Backend 3**:

- ✅ Tests funcionales básicos (Mocha + Supertest) para **adoption.router.js** en `test/supertest.test.js`  
- ✅ **Dockerfile** para generar la imagen del proyecto  
- ✅ **Swagger** documentando el módulo **Users** disponible en **/api/docs**  
- ✅ `.env` incluido con valores genéricos  
- ✅ `node_modules` excluido

## Scripts
```bash
npm install
npm run dev   # o 'node src/app.js' según tu estructura
npm test
```

## Docker
```bash
# Construir
docker build -t jpramognino/backend3:latest .

# Correr
docker run --env-file .env -p 8080:8080 jpramognino/backend3:latest
```

### Docker Hub
> Sube tu imagen con:
```bash
docker login
docker tag jpramognino/backend3:latest jpramognino/backend3:latest
docker push jpramognino/backend3:latest
```
Luego agrega el link público de Docker Hub aquí:
**https://hub.docker.com/r/jpramognino/backend3**

## Swagger
- Documentación de **Users** en: `GET /api/docs`

---
Autor: **JPRamognino**
