import chai from "chai";
import supertest from "supertest";
import app from "../src/app.js";

const expect = chai.expect;
const request = supertest(app);

// Estos tests son básicos pero alcanzan para comprobar
// que las rutas principales responden y que adoption.router.js
// está correctamente montado.

describe("Test de integración de la API", () => {

  describe("Rutas de usuarios", () => {
    it("GET /api/users responde 200 o 204", async () => {
      const response = await request.get("/api/users");
      expect([200, 204]).to.include(response.status);
    });
  });

  describe("Rutas de adopciones", () => {
    it("GET /api/adoptions responde 200, 204 o 404", async () => {
      const response = await request.get("/api/adoptions");
      expect([200, 204, 404]).to.include(response.status);
    });

    it("GET /api/adoptions/:aid responde 200 o 404", async () => {
      // Usamos un ID inventado, alcanza con validar que el endpoint existe
      const response = await request.get("/api/adoptions/123456789012345678901234");
      expect([200, 404]).to.include(response.status);
    });

    it("POST /api/adoptions/:uid/:pid responde 200/400/404", async () => {
      // IDs ficticios: el objetivo es chequear que la ruta está definida
      const fakeUserId = "123456789012345678901234";
      const fakePetId = "987654321098765432109876";

      const response = await request.post(`/api/adoptions/${fakeUserId}/${fakePetId}`);
      expect([200, 400, 404]).to.include(response.status);
    });
  });

});
