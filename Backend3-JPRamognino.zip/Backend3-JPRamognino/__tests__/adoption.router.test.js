const request = require('supertest');

let app;
beforeAll(() => {
  // Importamos la app sin levantar el listener
  app = require('../src/app');
});

describe('Adoption Router - functional', () => {
  it('GET /api/adoptions debe responder 200', async () => {
    const res = await request(app).get('/api/adoptions');
    expect([200,204,404]).toContain(res.statusCode);
  });

  it('POST /api/adoptions responde adecuadamente (201/400/401)', async () => {
    const res = await request(app)
      .post('/api/adoptions')
      .send({ petId: 'mock-pet-id', userId: 'mock-user-id' });
    expect([201,400,401,404]).toContain(res.statusCode);
  });

  it('GET /api/adoptions/:aid responde 200/404', async () => {
    const res = await request(app).get('/api/adoptions/test-id');
    expect([200,404]).toContain(res.statusCode);
  });
});